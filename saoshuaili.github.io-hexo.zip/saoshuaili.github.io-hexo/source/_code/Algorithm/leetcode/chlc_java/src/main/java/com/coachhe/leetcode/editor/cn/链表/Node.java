package com.coachhe.leetcode.editor.cn.链表;

/**
 * @author CoachHe
 * @date 2022/8/17 03:11
 **/
public class Node {
    public int val;
    public Node next;
    public Node random;

    public Node(int val) {
        this.val = val;
        this.next = null;
        this.random = null;
    }
}