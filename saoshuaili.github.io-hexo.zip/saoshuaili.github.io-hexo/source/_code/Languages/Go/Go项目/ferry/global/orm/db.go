package orm

import (
	"github.com/jinzhu/gorm"
)

var Eloquent *gorm.DB
var MysqlConn string

