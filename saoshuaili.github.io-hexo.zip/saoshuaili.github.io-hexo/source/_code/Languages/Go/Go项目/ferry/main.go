package main

import (
	"ferry/cmd"
)

func main() {
	cmd.Execute()
}
