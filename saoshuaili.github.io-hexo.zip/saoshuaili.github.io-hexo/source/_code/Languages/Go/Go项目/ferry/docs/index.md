# 目录

* [介绍](https://lanyulei.github.io/ferry/document/introduction "介绍")
* [安装](https://lanyulei.github.io/ferry/document/install "安装")
* [IDE 开发](https://lanyulei.github.io/ferry/document/ide_development "IDE 开发")
* [系统管理](https://lanyulei.github.io/ferry/document/system_manager "系统管理")
* 工单系统
* * [创建一个新流程](https://lanyulei.github.io/ferry/document/new_process "创建一个新流程")
* * [催办](https://lanyulei.github.io/ferry/document/urge "催办")
* * [转交](https://lanyulei.github.io/ferry/document/forward "转交")
* * [结单](https://lanyulei.github.io/ferry/document/end_process "结单")
* * [排他网关](https://lanyulei.github.io/ferry/document/exclusive_gateway "排他网关")
* * [并行网关](https://lanyulei.github.io/ferry/document/parallel_gateway "并行网关")
* * [会签](https://lanyulei.github.io/ferry/document/countersign "会签")
* [Mac、Linux、Windows下分别进行交叉编译](https://lanyulei.github.io/ferry/document/cross_compile "Mac、Linux、Windows下分别进行交叉编译")
