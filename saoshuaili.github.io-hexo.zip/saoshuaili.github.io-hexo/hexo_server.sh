#!/bin/bash

source /etc/profile

nohup hexo s >/dev/null 2>&1 &
