echo "hexo clean"
hexo clean 

echo "hexo g"
hexo g 

echo "hexo d"
hexo d
